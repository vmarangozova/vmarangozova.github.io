
public class TestCountry {
	
	public static void main(String[] args) throws Exception {
		
		Country c = Country.getCountryAt(-1.0, -1.0);
		
		Double d = Double.parseDouble("");
		System.out.println(d);
		
	}
}
