name := "stream-word-count"

version := "1.0"

scalaVersion := "2.13.16"


libraryDependencies ++= Seq(
  "org.apache.spark" %% "spark-core" % "4.0.0",
  "org.apache.spark" %% "spark-sql" % "4.0.0",
  "org.apache.spark" %% "spark-streaming" % "4.0.0"
)